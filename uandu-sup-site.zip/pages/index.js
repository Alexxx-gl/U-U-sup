
import Image from 'next/image'

export default function Home() {
  return (
    <div className="font-sans text-gray-800 bg-white">
      {/* Header */}
      <header className="p-6 bg-gradient-to-r from-blue-400 to-indigo-500 text-white shadow-md flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Image src="/Screenshot 2025-04-17 104104.png" width={50} height={50} alt="Logo" />
          <h1 className="text-3xl font-bold">U&U Sup</h1>
        </div>
        <button className="bg-white text-blue-600 px-4 py-2 rounded-xl shadow hover:bg-blue-100">Switch to Русский</button>
      </header>

      {/* Hero */}
      <section className="text-center p-12 bg-blue-50">
        <h2 className="text-2xl mb-4 italic">“Let us manage all the difficulties and organisation. So that you can finally relax and have a joyful time.”</h2>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-2xl mt-4 hover:bg-blue-700 shadow">Book Your Adventure</button>
      </section>

      {/* Route */}
      <section className="p-8">
        <h2 className="text-2xl font-semibold mb-4">🗺️ Explore Our Route</h2>
        <p>An uncharted, low-sup-intensity path through untouched nature.</p>
        <div className="my-4 h-64 bg-gray-200 flex items-center justify-center">[Map Image or Embed]</div>
      </section>

      {/* Why Choose Us */}
      <section className="bg-gray-50 p-8">
        <h2 className="text-2xl font-semibold mb-4">🤝 Why Choose Us?</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>We eliminated all the excess components for which other companies charge twice more.</li>
          <li>Simplified the entire process and “trip mechanism”.</li>
          <li>The fewer details – the cheaper.</li>
          <li>New, unknown low-sup-intensity route.</li>
        </ul>
      </section>

      {/* Price Breakdown */}
      <section className="p-8">
        <h2 className="text-2xl font-semibold mb-4">💸 Price Breakdown</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>Organization of an uncharted route</li>
          <li>All necessary equipment included</li>
          <li>Bus transfer from and to the platform</li>
          <li>Simplicity and relaxation guaranteed</li>
        </ul>
      </section>

      {/* Video */}
      <section className="bg-gray-50 p-8">
        <h2 className="text-2xl font-semibold mb-4">🎥 Route Video</h2>
        <div className="h-64 bg-gray-200 flex items-center justify-center">[Video Embed Here]</div>
      </section>

      {/* Photos */}
      <section className="p-8">
        <h2 className="text-2xl font-semibold mb-4">📸 Route Photos</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-200 h-40 flex items-center justify-center">[Photo 1]</div>
          <div className="bg-gray-200 h-40 flex items-center justify-center">[Photo 2]</div>
          <div className="bg-gray-200 h-40 flex items-center justify-center">[Photo 3]</div>
          <div className="bg-gray-200 h-40 flex items-center justify-center">[Photo 4]</div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-gray-50 p-8">
        <h2 className="text-2xl font-semibold mb-4">❓ FAQ</h2>
        <ul className="space-y-4">
          <li><strong>Do I need SUP experience?</strong> – No, beginners welcome!</li>
          <li><strong>What should I bring?</strong> – Just clothes, sunscreen, and your adventurous spirit!</li>
          <li><strong>Is transportation included?</strong> – Yes! Full guidance from platform to platform.</li>
          <li><strong>How to book?</strong> – Use the form below or click the button at the top.</li>
        </ul>
      </section>

      {/* Contact Form */}
      <section className="p-8">
        <h2 className="text-2xl font-semibold mb-4">📬 Get in Touch</h2>
        <form className="grid gap-4 max-w-lg mx-auto">
          <input type="text" placeholder="Your Name" className="p-3 border rounded-xl" />
          <input type="email" placeholder="Your Email" className="p-3 border rounded-xl" />
          <textarea placeholder="Message or Request" className="p-3 border rounded-xl h-32" />
          <button type="submit" className="bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700">Send</button>
        </form>
      </section>

      <footer className="text-center p-6 text-sm text-gray-400">
        U&U Sup – The best for the lowest price.
      </footer>
    </div>
  )
}
